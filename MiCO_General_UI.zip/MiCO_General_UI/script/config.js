/**
 * Created by rocke on 15-7-21.
 */
var appId='rkb3roqqvevl2rctavxz8p94sfqwdne9s5gudiyhsicxovuh';
var appKey='rtige83c3quf57nwd8786o62txm7jdwsavluv77rrcvjbljs';

//APP_ID
var APP_ID = "a4fd19d9-cfc8-4190-9128-971bbfe9ccc3";
//APP_NAME
var APP_NAME = "MiCOAPP";