mico相关的sdk见其他的md文件
add new ssh key